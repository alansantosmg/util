05/28/2024
Dwight W Middlebrook
hyper.accelerated@gmx.com

Simple service menu to launch kcalc.Of course make sure its installed. Fire the install script. Desktop files are installed in .local/share/kio/servicemenus. If it does not appear in the menu. Go to .local/share/kio/servicemenus make sure .desktop is checked executable.
