#!/bin/bash
target_dir=~/.local/share/kio/servicemenus
cd $target_dir
rm -rf kcalc.desktop
exit
